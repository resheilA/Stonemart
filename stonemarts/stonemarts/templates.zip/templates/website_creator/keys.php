<?php
  $authid = "632689";
  $apikey = "7PfVXjBwQ6FDnKUGr0zaLfTrHEjTGysF";
?>