<?php
include("keys.php");

/*
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://test.httpapi.com/api/domains/available.json?auth-userid='.$authid.'&api-key='.$apikey.'&domain-name=domain1&tlds=com');
$result = curl_exec($ch);


print_r($result);
curl_close($ch);
  	
  	$url = 'https://test.httpapi.com/api/domains/available.json?auth-userid='.$authid.'&api-key='.$apikey.
  	'&domain-name=domain1&tlds=com';
		  var_dump(file_get_contents($url, true));
	$details = json_decode(file_get_contents($url), true);
	var_dump($details);
	echo $details[2]["entity.description"];
*/
?>


